# Project-Rectangle
[X-GIL-Lab] Test technique

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run build

### Open file 
```

Open "/dist" and click index.html 