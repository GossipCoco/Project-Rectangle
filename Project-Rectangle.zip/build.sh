#!/bin/bash
tsc
cp src/index.html dist/index.html
cp src/styles.css dist/styles.css
